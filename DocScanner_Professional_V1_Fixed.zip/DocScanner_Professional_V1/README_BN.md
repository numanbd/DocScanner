# Doc Scanner Professional V1

Professional Android Studio project for a document scanner app.

## Features included in this foundation
- English + Bangla UI
- Light professional theme
- Camera scan with CameraX
- Gallery import
- Auto crop basic pipeline
- Enhance / Clear filter
- Black & White filter
- Rotate
- Multi-page PDF export
- Save PDF to Downloads/Doc Scanner
- Recent PDF list
- OCR screen with Bangla / English / mixed language option

## Important OCR setup
For Bangla OCR to work, put these files in:

`app/src/main/assets/tessdata/`

Required files:
- `ben.traineddata`
- `eng.traineddata`

The app code is already connected with Tesseract4Android. Without traineddata files, the OCR screen will show a missing-data message.

## Open in Android Studio
1. Extract ZIP
2. Android Studio → Open
3. Select the `DocScanner_Professional_V1` folder
4. Gradle Sync
5. Run on phone

## Build APK
Android Studio:

`Build → Build Bundle(s) / APK(s) → Build APK(s)`

## Next professional upgrades
- True OpenCV contour-based edge detection
- Manual corner crop UI
- Perspective transform screen
- Full PDF tools: watermark, signature, lock, merge, compress
- Room database
- Search by OCR text

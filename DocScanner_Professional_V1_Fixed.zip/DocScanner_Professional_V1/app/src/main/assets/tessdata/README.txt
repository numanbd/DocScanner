For offline OCR, add Tesseract traineddata files here before building:
- ben.traineddata  (Bangla OCR)
- eng.traineddata  (English OCR)

Recommended source: official Tesseract tessdata repository.
Do not rename the files.

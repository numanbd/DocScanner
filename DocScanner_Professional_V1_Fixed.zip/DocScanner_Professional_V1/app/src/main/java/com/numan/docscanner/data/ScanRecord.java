package com.numan.docscanner.data;
public class ScanRecord { public String name; public String pdfPath; public long created; public int pages; public String ocrText; }

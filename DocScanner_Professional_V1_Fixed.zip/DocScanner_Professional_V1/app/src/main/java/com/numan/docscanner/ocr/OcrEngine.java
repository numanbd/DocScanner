package com.numan.docscanner.ocr;

import android.content.Context;import java.io.*;import cz.adaptech.tesseract4android.TessBaseAPI;
public class OcrEngine{
 public static String dataDir(Context c){return new File(c.getFilesDir(),"tesseract").getAbsolutePath();}
 public static boolean hasData(Context c){File d=new File(dataDir(c),"tessdata");return new File(d,"ben.traineddata").exists()||new File(d,"eng.traineddata").exists();}
 public static String recognize(Context c,String imagePath,String lang)throws Exception{
  File d=new File(dataDir(c),"tessdata"); if(!d.exists())d.mkdirs();
  if(!hasData(c)) return "OCR data missing. Copy ben.traineddata and eng.traineddata to: "+d.getAbsolutePath();
  TessBaseAPI api=new TessBaseAPI(); if(!api.init(dataDir(c),lang)){return "OCR init failed for language: "+lang;}
  api.setImage(new File(imagePath)); String text=api.getUTF8Text(); api.recycle(); return text==null?"":text;
 }
}

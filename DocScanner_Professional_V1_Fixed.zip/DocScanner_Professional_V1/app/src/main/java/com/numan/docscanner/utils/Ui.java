package com.numan.docscanner.utils;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;

public class Ui {
    public static int dp(Context c, int v){ return (int)(v*c.getResources().getDisplayMetrics().density+0.5f); }
    public static TextView title(Context c, String s, int sp){ TextView t=new TextView(c); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(23,33,43)); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    public static TextView sub(Context c, String s){ TextView t=new TextView(c); t.setText(s); t.setTextSize(14); t.setTextColor(Color.rgb(95,107,118)); return t; }
    public static Button button(Context c, String s){ Button b=new Button(c); b.setText(s); b.setAllCaps(false); b.setTextSize(15); return b; }
    public static GradientDrawable bg(int color, int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g; }
    public static TextView card(Context c, String emoji, String label, View.OnClickListener l){
        TextView v=new TextView(c); v.setText(emoji+"\n"+label); v.setGravity(android.view.Gravity.CENTER); v.setTextSize(15); v.setTextColor(Color.rgb(23,33,43)); v.setBackground(bg(Color.WHITE, dp(c,16))); v.setPadding(dp(c,8),dp(c,12),dp(c,8),dp(c,12)); v.setOnClickListener(l); return v;
    }
}

package com.numan.docscanner.pdf;

import android.content.Context;import android.graphics.*;import android.graphics.pdf.PdfDocument;import android.os.Environment;import java.io.*;import java.text.*;import java.util.*;
public class PdfMaker{
 public static File create(Context c, java.util.List<String> imagePaths, String name)throws Exception{
  File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"Doc Scanner"); if(!dir.exists())dir.mkdirs();
  File file=new File(dir,name+".pdf"); PdfDocument pdf=new PdfDocument(); Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
  for(String p:imagePaths){Bitmap bmp=BitmapFactory.decodeFile(p); if(bmp==null)continue; int pw=595,ph=842; PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(pw,ph,imagePaths.indexOf(p)+1).create(); PdfDocument.Page page=pdf.startPage(info); Canvas canvas=page.getCanvas(); canvas.drawColor(Color.WHITE); Rect dst=fitRect(bmp.getWidth(),bmp.getHeight(),pw,ph); canvas.drawBitmap(bmp,null,dst,paint); pdf.finishPage(page);} 
  FileOutputStream os=new FileOutputStream(file);pdf.writeTo(os);os.close();pdf.close();return file;
 }
 private static Rect fitRect(int bw,int bh,int pw,int ph){float s=Math.min(pw/(float)bw,ph/(float)bh);int w=(int)(bw*s),h=(int)(bh*s);int l=(pw-w)/2,t=(ph-h)/2;return new Rect(l,t,l+w,t+h);} 
 public static String defaultName(){return "DocScanner_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
}

package com.numan.docscanner.core;

import android.graphics.*;import java.io.*;
public class ImageProcessor{
 public static Bitmap rotate(Bitmap src){android.graphics.Matrix m=new android.graphics.Matrix();m.postRotate(90);return Bitmap.createBitmap(src,0,0,src.getWidth(),src.getHeight(),m,true);} 
 public static Bitmap enhance(Bitmap src){Bitmap out=Bitmap.createBitmap(src.getWidth(),src.getHeight(),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(out);Paint p=new Paint();ColorMatrix cm=new ColorMatrix(new float[]{1.22f,0,0,0,12,0,1.22f,0,0,12,0,0,1.22f,0,12,0,0,0,1,0});p.setColorFilter(new ColorMatrixColorFilter(cm));c.drawBitmap(src,0,0,p);return out;}
 public static Bitmap bw(Bitmap src){Bitmap out=Bitmap.createBitmap(src.getWidth(),src.getHeight(),Bitmap.Config.ARGB_8888);Canvas c=new Canvas(out);Paint p=new Paint();ColorMatrix cm=new ColorMatrix();cm.setSaturation(0);ColorMatrix cm2=new ColorMatrix(new float[]{1.35f,0,0,0,-35,0,1.35f,0,0,-35,0,0,1.35f,0,-35,0,0,0,1,0});cm.postConcat(cm2);p.setColorFilter(new ColorMatrixColorFilter(cm));c.drawBitmap(src,0,0,p);return out;}
 public static Bitmap smartCrop(Bitmap src){int w=src.getWidth(),h=src.getHeight();int padX=(int)(w*.06),padY=(int)(h*.06);return Bitmap.createBitmap(src,padX,padY,w-2*padX,h-2*padY);} 
 public static void saveJpeg(Bitmap b,File f)throws Exception{FileOutputStream os=new FileOutputStream(f);b.compress(Bitmap.CompressFormat.JPEG,92,os);os.close();}
 public static Bitmap load(String path){return BitmapFactory.decodeFile(path);} }

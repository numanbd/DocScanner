package com.numan.docscanner.ui;

import android.Manifest;import android.app.*;import android.os.*;import android.content.*;import android.provider.Settings;import android.view.*;import android.widget.*;import android.net.Uri;import java.util.*;import com.numan.docscanner.utils.Ui;import com.numan.docscanner.data.*;

public class MainActivity extends Activity{
 LinearLayout root,recents; int green=0xff00897B;
 @Override public void onCreate(Bundle b){super.onCreate(b); build();}
 void build(){
  ScrollView sv=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,86));root.setBackgroundColor(0xffF7F9FA);sv.addView(root);setContentView(sv);
  root.addView(Ui.title(this,"Doc Scanner",38)); root.addView(Ui.sub(this,"ডকুমেন্ট স্ক্যান, বাংলা OCR, PDF তৈরি"));
  TextView search=new TextView(this); search.setText("🔍  Search documents / ডকুমেন্ট খুঁজুন"); search.setTextSize(15); search.setTextColor(0xff60717f); search.setPadding(Ui.dp(this,14),Ui.dp(this,12),Ui.dp(this,14),Ui.dp(this,12)); search.setBackground(Ui.bg(0xffffffff,Ui.dp(this,16))); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.setMargins(0,Ui.dp(this,18),0,Ui.dp(this,12)); root.addView(search,sp);
  GridLayout grid=new GridLayout(this);grid.setColumnCount(4); root.addView(grid,new LinearLayout.LayoutParams(-1,-2));
  addTool(grid,"📷","Smart Scan\nস্মার্ট স্ক্যান",v->startActivity(new Intent(this,CameraActivity.class)));
  addTool(grid,"🖼️","Import\nইম্পোর্ট",v->pickImage());
  addTool(grid,"📄","PDF Tools\nপিডিএফ",v->toast("Open a scan first / আগে স্ক্যান করুন"));
  addTool(grid,"abc","OCR Text\nটেক্সট",v->toast("Open a scan first / আগে স্ক্যান করুন"));
  addTool(grid,"🆔","ID Cards\nআইডি কার্ড",v->startActivity(new Intent(this,CameraActivity.class).putExtra("mode","id")));
  addTool(grid,"✨","Enhance\nপরিষ্কার",v->toast("After scan / স্ক্যানের পরে"));
  addTool(grid,"✍️","Sign\nসাইন",v->toast("Coming in editor / এডিটরে থাকবে"));
  addTool(grid,"☰","All Tools\nসব টুলস",v->showTools());
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);head.setPadding(0,Ui.dp(this,24),0,Ui.dp(this,8));TextView r=Ui.title(this,"Recents",28);head.addView(r,new LinearLayout.LayoutParams(0,-2,1));TextView view=Ui.sub(this,"View All ›");head.addView(view);root.addView(head);
  recents=new LinearLayout(this);recents.setOrientation(LinearLayout.VERTICAL);root.addView(recents);loadRecents();
  Button scan=Ui.button(this,"📷  Scan Document / স্ক্যান করুন");scan.setTextColor(0xffffffff);scan.setBackground(Ui.bg(green,Ui.dp(this,18)));scan.setOnClickListener(v->startActivity(new Intent(this,CameraActivity.class)));root.addView(scan,new LinearLayout.LayoutParams(-1,Ui.dp(this,58)));
 }
 void addTool(GridLayout g,String e,String l,View.OnClickListener cl){TextView c=Ui.card(this,e,l,cl);GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=(getResources().getDisplayMetrics().widthPixels-Ui.dp(this,54))/4;p.height=Ui.dp(this,94);p.setMargins(Ui.dp(this,4),Ui.dp(this,4),Ui.dp(this,4),Ui.dp(this,4));g.addView(c,p);} 
 void loadRecents(){recents.removeAllViews();ArrayList<ScanRecord>a=RecordStore.all(this);if(a.isEmpty()){recents.addView(Ui.sub(this,"No recent PDF yet / এখনো কোনো PDF নেই"));return;}for(ScanRecord x:a){TextView t=Ui.card(this,"📄",x.name+"\n"+x.pages+" pages",v->{Intent in=new Intent(Intent.ACTION_VIEW);in.setDataAndType(Uri.parse("file://"+x.pdfPath),"application/pdf");in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(in);}catch(Exception ex){toast("PDF saved: "+x.pdfPath);}});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,Ui.dp(this,82));lp.setMargins(0,0,0,Ui.dp(this,8));recents.addView(t,lp);} }
 void showTools(){final String[]items={"Smart Scan","Import Images","Create PDF","Bangla OCR","English OCR","Enhance","Black & White","Watermark","Signature","Lock PDF","Book Scan","ID Card"};new AlertDialog.Builder(this).setTitle("Tools / টুলস").setItems(items,(d,which)->toast(items[which])).show();}
 void pickImage(){Intent i=new Intent(Intent.ACTION_PICK);i.setType("image/*");startActivityForResult(i,22);} @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==22&&c==RESULT_OK&&d!=null){startActivity(new Intent(this,ProcessActivity.class).setData(d.getData()));}}
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}

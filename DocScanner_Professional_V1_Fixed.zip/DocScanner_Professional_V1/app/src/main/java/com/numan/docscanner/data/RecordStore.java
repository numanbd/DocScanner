package com.numan.docscanner.data;

import android.content.Context;import android.content.SharedPreferences;import com.google.gson.Gson;import com.google.gson.reflect.TypeToken;import java.lang.reflect.Type;import java.util.*;
public class RecordStore{
 private static final String P="records",K="items"; public static ArrayList<ScanRecord> all(Context c){SharedPreferences sp=c.getSharedPreferences(P,0);String s=sp.getString(K,"[]");Type t=new TypeToken<ArrayList<ScanRecord>>(){}.getType();ArrayList<ScanRecord> a=new Gson().fromJson(s,t);return a==null?new ArrayList<>():a;}
 public static void add(Context c,ScanRecord r){ArrayList<ScanRecord>a=all(c);a.add(0,r);c.getSharedPreferences(P,0).edit().putString(K,new Gson().toJson(a)).apply();}
}
